<?php $__env->startSection('content'); ?>

<div class="content-body">
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(session()->has('fail')): ?>
        <div class="alert alert-fail" role="alert">
            <?php echo e(session('fail')); ?>

        </div>
        <?php endif; ?>
    <div class="container-fluid">

        <div class="row page-titles">

            <ol class="breadcrumb">

                <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php echo e(auth()->user()->role); ?></a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)">profile</a></li>
            </ol>
        </div>
        <!-- row -->
        <div class="row">

            <div class="col-xl-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Profile</h4>
                    </div>
                    <div class="card-body">
                        <div class="basic-form">
                            <form action="<?php echo e(route('profile.update', auth()->user()->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Name</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" placeholder="Nama..." value="<?php echo e(auth()->user()->name); ?>" name="name">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Golongan</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" placeholder="Golonga.." value="<?php echo e(auth()->user()->golongan); ?>" readonly>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Bagian</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" placeholder="Bagian.." value="<?php echo e(auth()->user()->division->name); ?>" readonly>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Username</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" placeholder="Username.." value="<?php echo e(auth()->user()->username); ?>" readonly>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <div class="col-sm-6">
                                        <button type="submit" class="btn btn-primary">Update profile</button>
                                        <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-danger">Batal</a>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ganti password</h4>
                    </div>
                    <div class="card-body">
                        <div class="basic-form">
                            <form action="<?php echo e(route('change.passwords')); ?>" method="post">
                                <?php echo csrf_field(); ?>


                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Username</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" placeholder="Username.." value="<?php echo e(auth()->user()->username); ?>" readonly>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Password baru</label>
                                    <div class="col-sm-9">
                                        <input type="password" class="form-control" name="password" placeholder="Password baru..">
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-sm-3 col-form-label">Confirm Password</label>
                                    <div class="col-sm-9">
                                        <input type="password" class="form-control" name="confirm_password" placeholder="Password baru..">
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">Update Password</button>
                                        <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-danger">Batal</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/profile/index.blade.php ENDPATH**/ ?>