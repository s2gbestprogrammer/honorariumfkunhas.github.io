<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="ms-3 mb-3">
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary"><b> <i class="fas fa-user-plus"></i>  &nbsp; Dosen </b></a>
                </div>
                <div class="card">
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card-header">
                        <h4 class="card-title"></h4>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example3" class="display" style="min-width: 845px">
                                <thead>
                                    <tr>

                                        <th>Name</th>
                                        <th>Golongan</th>
                                        <th>Bagian</th>
                                        <th>Rekening</th>
                                        <th>Bank</th>

                                        <th>Joining Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 0; ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php
                                    if($user->role == "super-admin" || $user->role == "admin"){
                                    $hidden = "hidden";

                                    } else {
                                        $hidden = "";
                                    }
                                    ?>
                                    <tr <?php echo e($hidden); ?>>

                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->golongan); ?></td>
                                        <td><?php echo e($user->division->name); ?></td>
                                        <td><?php echo e($user->rekening); ?></td>
                                        <td><?php echo e($user->bank); ?></td>
                                        <td><?php echo e($user->created_at); ?></td>

                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a>
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post" class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-danger shadow btn-xs sharp me-1 border-0" onclick="return confirm('Jika anda menghapus ini maka seluruh data honornya akan terhapus, Apakah anda yakin menghapus ini?')"><i class="fas fa-trash"></i></button>

                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>


</script>

<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/users/index.blade.php ENDPATH**/ ?>