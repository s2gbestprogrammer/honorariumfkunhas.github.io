<?php $__errorArgs = ['golongan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<?php echo e($message); ?>

<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['division_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<?php echo e($message); ?>

<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<form action="<?php echo e(route('users.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    name :<input type="text" name="name"> <br>
    username :<input type="text" name="username"> <br>
    golongan :
    <select name="golongan" id="golongan">
        <option value="">---- pilih golongan -----</option>
        <option value="I">I</option>
        <option value="II">II</option>
        <option value="III">III</option>
        <option value="IV">IV</option>
    </select> <br>
    bagian :
    <select name="division_id" id="division_id">
        <option value="">---- pilih role -----</option>
        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select> <br>

    rekening :<input type="text" name="rekening"> <br>
    bank :<input type="text" name="bank"> <br>

    <?php if(auth()->user()->role == "super-admin"): ?>
    <select name="role">
        <option value="">---- pilih role -----</option>
        <option value="admin">Admin biasa</option>
        <option value="dosen">Dosen</option>
    </select>
    <?php else: ?>

    password : <input type="text" name="password"> <br>

    <input type="hidden" name="role" value="dosen"> <br>
    <?php endif; ?>

    <br>
    <button type="submit">Daftar</button>
</form>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/users/create.blade.php ENDPATH**/ ?>