<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header"><h3>Print</h3></div>
                    <div class="card-body">

                        <div class="mb-3">
                            <div class="col-sm-6">
                                <form action="<?php echo e(route('print.searchByDate')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label class="">From</label>
                                        <input type="date" class="form-control" value="" name="from">
                                    </div>
                                    <div class="mb-3">
                                        <label class="">To</label>
                                        <input type="date" class="form-control" value="" name="to">
                                    </div>
                                    <button class="btn btn-primary" type="submit">FILTER BY DATE</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/print/index.blade.php ENDPATH**/ ?>