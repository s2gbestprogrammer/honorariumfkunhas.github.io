

<?php $__env->startSection('content'); ?>
	<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-12">
                        <div class="card tryal-gradient">
                        <div class="card-body tryal row">
                            <div class="col-xl-7 col-sm-6">
                                

                            </div>

                        </div>
                    </div>
					</div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/index.blade.php ENDPATH**/ ?>