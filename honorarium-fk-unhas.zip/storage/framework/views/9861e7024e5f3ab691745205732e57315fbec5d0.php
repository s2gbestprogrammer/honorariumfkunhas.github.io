<form action="<?php echo e(route('honor.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

     <input type="hidden" name="user_id" value="<?php echo e($users->id); ?>"><br>
    jumlah honor :<input type="text" name="jumlah_honor"><br>
    <input type="hidden" name="golongan" value="<?php echo e($users->golongan); ?>"> <br>

    keterangan

    <select name="category_id">
        <?php $__currentLoopData = $keterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($k->id); ?>"><?php echo e($k->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>



    <button type="submit">tambah honor</button>
</form>
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/honor/show.blade.php ENDPATH**/ ?>