


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">

<div class="col-12">
    <div class="ms-3 mb-3 d-inline">

        <a href="<?php echo e(route('honor.index')); ?>" class="btn btn-primary"><b> + Tambah Honor</b></a>

    </div>
    <div class="ms-3 mb-3 d-inline">

        <a href="<?php echo e(route('print.honor')); ?>" class="btn btn-primary"><b> PRINT </b></a>

    </div>
    <div class="card mt-3">

        <div class="card-header">
            <h4 class="card-title">Data honor</h4>
        </div>

        <div class="card-body">
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success m-3" role="alert">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table id="example3" class="display" style="min-width: 845px">
                    <thead>
                        <tr>

                            <td>No</td>
                            <td>Tanggal</td>
                            <td>Nama</td>
                            <td>Jumlah honor</td>
                            <td>Potongan</td>
                            <td>Jumlah Diterima</td>
                            <td>Keterangan</td>
                            <td>REKENING</td>
                            <td>BANK</td>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor = 1; ?>
                        <?php $__currentLoopData = $honors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $honor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($nomor++); ?></td>
                            <td><?php echo e($honor->created_at); ?></td>
                            <td><?php echo e($honor->user->name); ?></td>
                            <td><?php echo e($honor->jumlah_honor); ?></td>
                            <td><?php echo e($honor->potongan); ?></td>
                            <td><?php echo e($honor->jumlah_diterima); ?></td>
                            <td><?php echo e($honor->category->name); ?></td>
                            <td><?php echo e($honor->user->rekening); ?></td>
                            <td><?php echo e($honor->user->bank); ?></td>


                            <td>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('honor.show',$honor->user->id)); ?>" class="btn btn-success shadow btn-xs sharp me-1"><i class="fas fa-eye"></i></a>
                                    <form action="<?php echo e(route('honor.destroy', $honor->id)); ?>" method="post" class="d-inline">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger shadow btn-xs sharp me-1 border-0" onclick="return confirm('are u sure?')"><i class="fas fa-trash"></i></button>

                                    </form>

                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/honor/create.blade.php ENDPATH**/ ?>