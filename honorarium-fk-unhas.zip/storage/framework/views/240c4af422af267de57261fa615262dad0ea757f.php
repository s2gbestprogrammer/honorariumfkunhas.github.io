<?php $__env->startSection('content'); ?>
 <div class="content-body">
    <?php $__errorArgs = ['jumlah_honor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger m-3" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger m-3" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <!-- row -->
        <div class="container-fluid">
          <div
            class="d-flex justify-content-between align-items-center flex-wrap">
            <form action="/dashboard/admin/honor">
            <div class="input-group contacts-search mb-4">
              <input
                type="text"
                name="search"
                class="form-control"
                placeholder="Search here..."
                value="<?php echo e(request('search')); ?>"
              />
              <span class="input-group-text"
                ><a href="javascript:void(0)"
                  ><button type="submit" class="btn border-0"><i class="flaticon-381-search-2"></i></button></a
              ></span>
            </div>
            </form>
            <div class="mb-4">
                <a
                  href="<?php echo e(route('honor.create')); ?>"
                  class="btn btn-primary btn-md"
                  ><i class="fas fa-list"></i> Honor</a
                >
              </div>
            
          </div>
          <div class="row">
            <div class="col-xl-12">
              <div class="row">
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php

                        if($user->role == "super-admin" || $user->role == "admin") {
                            $hidden = "hidden";
                        } else {
                            $hidden = "";
                        }
                    ?>
                  <div <?php echo e($hidden); ?>

                    class="col-xl-3 col-xxl-4 col-lg-4 col-md-6 col-sm-6 items"
                  >
                    <div class="card contact-bx item-content">
                      <div class="card-header border-0">
                        <div class="action-dropdown">
                          <div class="dropdown">
                            <div class="btn-link" data-bs-toggle="dropdown">
                              <svg
                                width="24"
                                height="24"
                                viewbox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                              >
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="card-body user-profile">
                        
                        <div class="media-body user-meta-info">
                          <h6 class="fs-18 font-w600 my-1">
                            <a
                              href="#"
                              class="text-black user-name"
                              data-name="Alan Green"
                              ><?php echo e($user->name); ?></a
                            >
                          </h6>
                          <p
                            class="fs-14 mb-3 user-work"
                            data-occupation="UI Designer"
                          >
                           Bagian : <?php echo e($user->division->name); ?>

                          </p>
                          <p
                            class="fs-14 mb-3 user-work"
                            data-occupation="UI Designer"
                          >

                            Golongan : <?php echo e($user->golongan); ?>



                           <?php
                            $gos = $user->honor->first();
                          $total_honor = $user->honor->sum('jumlah_honor');
                            $sekarang = now()->format('M/Y');
                          ?>

                          <p class="fs-12">Total honor : Rp.<?php echo e(number_format($total_honor)); ?></p>
                            <?php if($gos !== null): ?>
                            <?php
                                $honor_now = $gos->created_at->format('M/Y');

                            ?>

                            <?php if($sekarang == $honor_now): ?>
                            <?php
                                $hidden = "hidden";
                            ?>

                            <p class="fs-12 fw-bold">  Honor terbaru bulan ini : <?php echo e('Rp.'.number_format($gos->jumlah_diterima)); ?></b> </p>
                            <?php else: ?>
                            <?php
                                $hidden = "";
                            ?>
                            <?php endif; ?>
                            <?php endif; ?>


                            <p class="fs-12 text-danger" <?php echo e($hidden); ?>>Belum mendapatkan honor bulan ini</p>

                          <ul>

                            <li>
                              <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target=".bd-example-modal-sm" data-id="<?php echo e($user->id); ?>" data-golongan="<?php echo e($user->golongan); ?>" data-rek="<?php echo e($user->rekening); ?>" data-bank="<?php echo e($user->bank); ?>" class="payhonor"
                                ><i class="fas fa-donate"></i></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('honor.show', $user->id)); ?>"><i class="fas fa-eye"></i></a>
                            </li>

                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <?php echo e($users->links('pagination::bootstrap-4')); ?>

          </div>
        </div>
      </div>


      <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" id="payModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Beri Honor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                    </button>
                </div>
                <form action="<?php echo e(route('honor.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <select name="category_id" id="category_id" class="default-select form-control mb-2">
                                         <option value="">PILIH KATEGORI</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                <div class="modal-body" id="modalpay">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
            </div>
        </div>
    </div>



    <script>
        $(document).ready(function(){
            $('.payhonor').click(function(){
                var userid = $(this).data('id');
                var golongan = $(this).data('golongan');
                var rekening = $(this).data('rek');
                var bank = $(this).data('bank');
                $.ajax({
                    success: function(response) {
                        $('#payModal').modal('show');
                        $('#modalpay').html(`<input type="hidden" name="user_id" class="form-control" placeholder="amount" value="`+userid+`">`+
                        `<input type="number" name="jumlah_honor" class="form-control" value="" placeholder="Jumlah Honor">` + `<br>`+
                        `<input type="hidden" value="`+golongan+`" name="golongan">` +
                        `<input type="hidden" value="`+userid+`" name="user_id">` +
                        `<p>Kirim ke : <b> `+rekening+` | `+bank+` </b></p>`
                        );
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/honor/index.blade.php ENDPATH**/ ?>