<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->

</head>
<body>
    admin
    <form action="<?php echo e(route('authenticate')); ?>" method="post">
        <?php echo csrf_field(); ?>
        user :<input type="text" name="username"> <br>
        password : <input type="text" name="password"> <br>
        <button type="submit">login</button>
    </form>
</body>
</html>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/login.blade.php ENDPATH**/ ?>