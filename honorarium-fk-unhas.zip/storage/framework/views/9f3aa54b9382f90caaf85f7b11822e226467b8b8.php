<?php $__env->startSection('content'); ?>


<div class="content-body">

    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-12">
                <div class="card tryal-gradient">
                <div class="card-body tryal row">
                    <div class="col-xl-7 col-sm-6">
                        <h2>Selamat datang <?php echo e(auth()->user()->name); ?></h2>
                        <?php echo e($users); ?>

                        
                    </div>

                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/dosen/index.blade.php ENDPATH**/ ?>