<?php $__errorArgs = ['golongan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<?php echo e($message); ?>

<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php $__errorArgs = ['bagian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<?php echo e($message); ?>

<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<form action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    name :<input type="text" name="name"> <br>
    username :<input type="text" name="username"> <br>
    golongan :
    <select name="golongan" id="golongan">
        <option value="">---- pilih golongan -----</option>
        <option value="I">I</option>
        <option value="II">II</option>
        <option value="II">III</option>
        <option value="IV">IV</option>
    </select> <br>
    bagian :
    <select name="bagian" id="bagian">
        <option value="">---- pilih role -----</option>
        <option value="1">Ilmu kesehatan anak</option>
    </select> <br>
    password : <input type="text" name="password"> <br>

    <?php if(auth()->user()->role == "super-admin"): ?>
    <select name="role">
        <option value="">---- pilih role -----</option>
        <option value="admin">Admin biasa</option>
        <option value="dosen">Dosen</option>
    </select>
    <?php else: ?>

    <input type="hidden" name="role" value="dosen"> <br>
    <?php endif; ?>

    <br>
    <button type="submit">Daftar</button>
</form>
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/users/edit.blade.php ENDPATH**/ ?>