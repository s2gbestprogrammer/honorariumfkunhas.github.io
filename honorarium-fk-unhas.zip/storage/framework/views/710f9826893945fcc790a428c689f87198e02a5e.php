  <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="dlabnav">
            <div class="dlabnav-scroll">
				<ul class="metismenu" id="menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>

                    <li><a href="<?php echo e(route('dashboard.admin')); ?>" aria-expanded="false">
							<i class="fas fa-home"></i>
							<span class="nav-text">Beranda  </span>
						</a>


                    </li>
                    <li><a href="<?php echo e(route('users.index')); ?>" aria-expanded="false">
                        <i class="fas fa-users"></i>
                        <span class="nav-text">Pengguna</span>
                    </a>
                    <li><a href="<?php echo e(route('honor.index')); ?>" aria-expanded="false">
                        <i class="fas fa-hand-holding-usd"></i>
                        <span class="nav-text">Honor</span>
                    </a>
                    <li><a href="<?php echo e(route('divisions.index')); ?>" aria-expanded="false">
                        <i class="fas fa-clone"></i>
                        <span class="nav-text">Bagian</span>
                    </a>
                    <li><a href="<?php echo e(route('categories.index')); ?>" aria-expanded="false">
                        <i class="fas fa-table"></i>
                        <span class="nav-text">Kategori</span>
                    </a>
                    <li><a href="/dashboard/admin/feedback" aria-expanded="false">
                        <i class="fas fa-heart"></i>
                        <span class="nav-text">Feedback</span>
                    </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dosen')): ?>
                    <li><a href="<?php echo e(route('dashboard.dosen')); ?>" aria-expanded="false">
                        <i class="fas fa-home"></i>
                        <span class="nav-text">Beranda  </span>
                    </a>
                    </li>
                    <li><a href="<?php echo e(route('feedback.index')); ?>" aria-expanded="false">
                        <i class="fas fa-heart"></i>
                        <span class="nav-text">Feedback</span>
                    </a>
                    </li>
                    <li><a href="<?php echo e(route('dosen.honor.get', auth()->user()->id)); ?>" aria-expanded="false">
                        <i class="fas fa-heart"></i>
                        <span class="nav-text">Honor</span>
                    </a>
                    </li>

                    <?php endif; ?>



                </ul>

			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/partials/sidebar.blade.php ENDPATH**/ ?>