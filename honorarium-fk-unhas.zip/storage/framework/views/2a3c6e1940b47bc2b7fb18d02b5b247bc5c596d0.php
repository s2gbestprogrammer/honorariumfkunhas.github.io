<form action="<?php echo e(route('divisions.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="name">
    <button type="submit">tambah divisi</button>
</form>
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/division/create.blade.php ENDPATH**/ ?>