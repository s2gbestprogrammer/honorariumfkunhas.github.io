<?php if(session()->has('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<a href="<?php echo e(route('divisions.create')); ?>">Tambah bagian</a>
<table cellspacing="5px" border="1px">
    <tr>
        <td>Bagian</td>
    </tr>
    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($division->name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/division/index.blade.php ENDPATH**/ ?>