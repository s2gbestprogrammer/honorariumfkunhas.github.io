  <?php if(session()->has('success')): ?>
  <div class="alert alert-success" role="alert">
      <?php echo e(session('success')); ?>

  </div>
  <?php endif; ?>

  <table cellspacing="20px" border="1px">

      <tr>
          <td>No</td>
          <td>Nama</td>
          <td>Username</td>
          <td>Golongan</td>
          <td>Bagian</td>
          <td>rekening</td>
          <td>bank</td>
          <td>role</td>
          <td>Aksi</td>

      </tr>
      <?php $nomor = 0; ?>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <?php
      if($user->role == "super-admin" || $user->role == "admin"){
        $hidden = "hidden";

      } else {
          $hidden = "";
      }
      ?>
      

      <tr <?php echo e($hidden); ?>>
          <td><?php echo e($nomor++ - 1); ?></td>
          <td><?php echo e($user->name); ?></td>
          <td><?php echo e($user->username); ?></td>
          <td><?php echo e($user->golongan); ?></td>
          <td><?php echo e($user->division->name); ?></td>
          <td><?php echo e($user->rekening); ?></td>
          <td><?php echo e($user->bank); ?></td>
          <td><?php echo e($user->role); ?></td>
          <td>
              <a href="<?php echo e(route('honor.show', $user->id)); ?>">Beri honor</a>
              <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <button>Delete</button>
              </form>
          </td>
      </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <a href="/dashboard/admin" class="btn btn-primary">kembali ke home</a>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/honor/create.blade.php ENDPATH**/ ?>