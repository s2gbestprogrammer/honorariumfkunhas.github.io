
<table border="1px">
    <tr>
        <td>no</td>
        <td>nama</td>
        <td>jumlah diterima</td>
    </tr>
<?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($s->user->name); ?></td>
        <td><?php echo e($s->jumlah_diterima); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<script>
    window.print();
</script>
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/print/print.blade.php ENDPATH**/ ?>