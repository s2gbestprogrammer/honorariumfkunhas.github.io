
<?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($s->user->name); ?>

<?php echo e($s->jumlah_diterima); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    window.print();
</script>
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/print/print.blade.php ENDPATH**/ ?>