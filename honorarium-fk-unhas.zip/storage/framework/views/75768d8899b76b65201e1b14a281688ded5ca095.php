<form action="<?php echo e(route('profile.update', auth()->user()->id)); ?>">
    nama : <input type="text" value="<?php echo e(auth()->user()->name); ?>"> |
    <?php echo e(auth()->user()->division->name); ?> |
    <?php echo e(auth()->user()->golongan); ?> |<br>

    <button type="submit">ganti nama</button>
</form>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/profile/password.blade.php ENDPATH**/ ?>