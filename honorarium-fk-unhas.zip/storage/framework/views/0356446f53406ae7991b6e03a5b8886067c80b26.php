  <?php if(session()->has('success')): ?>
  <div class="alert alert-success" role="alert">
      <?php echo e(session('success')); ?>

  </div>
  <?php endif; ?>
  <a href="<?php echo e(route('honor.create')); ?>" class="btn btn-primary">tambah honor</a>
  <table cellspacing="20px" border="1px">

      <tr>
          <td>No</td>
          <td>Nama</td>
          <td>Golongan</td>
          <td>Bagian</td>
          <td>Jumlah honor</td>
          <td>Potongan</td>
          <td>Jumlah Diterima</td>
          <td>Keterangan</td>
          <td>role</td>
          <td>Aksi</td>

      </tr>
      <?php $nomor = 0; ?>
      <?php $__currentLoopData = $honors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $honor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <?php
      ?>
      

      <tr <?php echo e($hidden); ?>>
          <td><?php echo e($nomor++ - 1); ?></td>
          <td><?php echo e($honor->user->name); ?></td>
          <td><?php echo e($honor->user->golongan); ?></td>
          <td><?php echo e($honor->user->division->name); ?></td>
          <td><?php echo e($honor->jumlah_honor); ?></td>
          <td><?php echo e($honor->potongan); ?></td>
          <td><?php echo e($honor->jumlah_diterima); ?></td>
          <td><?php echo e($honor->keterangan); ?></td>
          <td><?php echo e($honor->user->role); ?></td>
          <td>
              <a href="">edit</a>
              <a href=""> detail </a>
              <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <button>Delete</button>
              </form>
          </td>
      </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <a href="/dashboard/admin" class="btn btn-primary">kembali ke home</a>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/honor/index.blade.php ENDPATH**/ ?>