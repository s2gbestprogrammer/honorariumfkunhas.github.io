<form action="<?php echo e(route('honor.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input name="jumlah_honor">

    <button type="submit">tambah honor</button>
</form>


<?php echo e($users); ?>

<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/honor/show.blade.php ENDPATH**/ ?>