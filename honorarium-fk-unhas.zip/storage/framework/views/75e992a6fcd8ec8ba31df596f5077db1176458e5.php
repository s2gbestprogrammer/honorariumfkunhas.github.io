Profilku
<form action="<?php echo e(route('profile.update', auth()->user()->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    nama : <input type="text" value="<?php echo e(auth()->user()->name); ?>" name="name"> |
    <?php echo e(auth()->user()->division->name); ?> |
    <?php echo e(auth()->user()->golongan); ?> |<br>

    <button type="submit">ganti nama</button>
</form>


<form action="/password/<?php echo e(auth()->user()->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    password baru : <input type="text" value="" name="password"> <br>
    <button type="submit">ganti password</button>
</form>


<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/profile/index.blade.php ENDPATH**/ ?>