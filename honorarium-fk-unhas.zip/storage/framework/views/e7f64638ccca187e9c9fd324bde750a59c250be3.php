<a href="<?php echo e(route('categories.create')); ?>">tambah category </a>
<table border="1px">
    <tr>
        <td>nama</td>
        <td>type</td>
    </tr>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($category->name); ?></td>
        <td><?php echo e($category->type); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH E:\FILE E\DataSuryaa\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/categories/index.blade.php ENDPATH**/ ?>