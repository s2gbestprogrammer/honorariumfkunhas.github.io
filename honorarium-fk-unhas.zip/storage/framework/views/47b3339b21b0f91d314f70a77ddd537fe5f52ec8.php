<form action="<?php echo e(route('categories.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    name : <input type="text" value="" name="name"> <br>
    type :
    <select name="type">
        <option value="semester">semester</option>
        <option value="bulan">bulan</option>
        <option value="kegiatan">kegiatan</option>
        <option value="tertentu">tertentu</option>
    </select>
    <br>

    <button type="submit">Tambah category</button>
</form>
<?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/admin/categories/create.blade.php ENDPATH**/ ?>