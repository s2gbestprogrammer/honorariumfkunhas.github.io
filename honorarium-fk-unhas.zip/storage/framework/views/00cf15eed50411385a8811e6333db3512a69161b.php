
<?php $__env->startSection('content'); ?>

<div class="content-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success m-3" role="alert">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <div class="container-fluid">

        <div class="row page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Feedback</a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)">dosen</a></li>
            </ol>
        </div>

        <!-- row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class=" ms-0 ms-sm-4 ms-sm-0">
                            <div class="compose-content">
                                <form action="<?php echo e(route('feedback.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>


                                    <div class="mb-3">
                                        <input type="text" class="form-control bg-transparent" placeholder=" Subject:" name="title">
                                    </div>
                                    <div class="mb-3">
                                        <textarea id="email-compose-editor" name="body" class="textarea_editor form-control bg-transparent" rows="15" placeholder="Enter text ..."></textarea>
                                    </div>

                            </div>
                            <div class="text-start mt-4 mb-3">
                                <button class="btn btn-primary btn-sl-sm me-2" type="submit"><span class="me-2"><i class="fa fa-paper-plane"></i></span>Send</button>
                            </form>
                                <button class="btn btn-danger light btn-sl-sm" id="discard" type="button"><span class="me-2"><i class="fa fa-times"></i></span>Discard</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<script>

    $(document).ready(function(){
            $('.btn-danger').click(function(){
                $('.form-control').val('');
            });


        });
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\MyApp\Laravel-app\honorarium-fk-unhas\resources\views/dashboard/dosen/feedback/index.blade.php ENDPATH**/ ?>